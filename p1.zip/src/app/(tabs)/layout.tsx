export default function TabsLayout({
                                       children,
                                   }: {
    children: React.ReactNode;
}) {
    return (
        <main className="">
            {children}
        </main>
    );
}