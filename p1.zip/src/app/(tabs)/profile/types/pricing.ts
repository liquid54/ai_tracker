export type PricingPlan = {
    title: string
    price: string
    description: string
    type: string
}