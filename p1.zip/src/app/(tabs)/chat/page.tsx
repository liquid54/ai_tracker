


const chatPage = () => {
    return (
        <main className="p-4">
            <p>Сторінка чату</p>
        </main>
    );
}


export default chatPage;