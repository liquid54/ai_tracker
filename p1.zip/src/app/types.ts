export interface IconProps {
    width?: number;
    height?: number;
    className?: string;
}