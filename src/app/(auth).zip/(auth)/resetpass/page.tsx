import ResetPage from "@/app/(auth)/resetpass/resetPage";


const ResetPass = () => {
    return <ResetPage/>
}

export default ResetPass;