import LoginPage from "@/app/(auth)/login/loginPage";


const Login = () => {
    return <LoginPage/>
}

export default Login;